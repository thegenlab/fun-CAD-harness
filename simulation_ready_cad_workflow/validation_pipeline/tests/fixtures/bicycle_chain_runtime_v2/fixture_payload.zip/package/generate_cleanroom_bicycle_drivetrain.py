from __future__ import annotations

import argparse
from datetime import datetime, timezone
from math import atan2, cos, degrees, pi, sin, sqrt
from pathlib import Path

from build123d import (
    Align,
    Box,
    Compound,
    Cylinder,
    Plane,
    Pos,
    Rot,
    Shape,
    Torus,
    Vector,
    export_step,
)


REAR_CENTER = Vector(-850.0, 0.0, 380.0)
CRANK_CENTER = Vector(-250.0, 0.0, 340.0)
FRONT_CENTER = Vector(800.0, 0.0, 380.0)
DRIVE_PLANE_Y_MM = -78.0
CHAIN_VISUAL_PLANE_Y_MM = -98.0
INPUT_PITCH_RADIUS_MM = 80.0
REAR_PITCH_RADIUS_MM = 40.0
DETERMINISTIC_TIMESTAMP = datetime(
    2026, 7, 28, 0, 0, 0, tzinfo=timezone.utc
)


def tube(start: Vector, end: Vector, radius: float) -> Shape:
    direction = end - start
    if direction.length <= 0.0:
        raise ValueError("tube endpoints must differ")
    return Plane(origin=start, z_dir=direction) * Cylinder(
        radius,
        direction.length,
        align=(Align.CENTER, Align.CENTER, Align.MIN),
    )


def extended_tube(
    start: Vector,
    end: Vector,
    radius: float,
    extension: float,
) -> Shape:
    direction = end - start
    if direction.length <= 0.0:
        raise ValueError("tube endpoints must differ")
    unit_direction = direction * (1.0 / direction.length)
    return tube(
        start - unit_direction * extension,
        end + unit_direction * extension,
        radius,
    )


def cylinder_y(center: Vector, radius: float, length: float) -> Shape:
    start = center + Vector(0.0, -length / 2.0, 0.0)
    return Plane(origin=start, z_dir=Vector(0.0, 1.0, 0.0)) * Cylinder(
        radius,
        length,
        align=(Align.CENTER, Align.CENTER, Align.MIN),
    )


def annulus_y(
    center: Vector,
    outer_radius: float,
    inner_radius: float,
    length: float,
) -> Shape:
    if not 0.0 < inner_radius < outer_radius:
        raise ValueError("annulus radii must satisfy 0 < inner < outer")
    outer = cylinder_y(center, outer_radius, length)
    inner = cylinder_y(center, inner_radius, length + 2.0)
    return outer.cut(inner).clean()


def torus_y(center: Vector, major_radius: float, minor_radius: float) -> Shape:
    return (
        Pos(center.X, center.Y, center.Z)
        * Rot(90.0, 0.0, 0.0)
        * Torus(major_radius, minor_radius)
    )


def centered_box(
    center: Vector,
    length: float,
    width: float,
    height: float,
    *,
    rotation_y_deg: float = 0.0,
) -> Shape:
    return (
        Pos(center.X, center.Y, center.Z)
        * Rot(0.0, rotation_y_deg, 0.0)
        * Box(length, width, height)
    )


def radial_point(
    center: Vector,
    radius: float,
    angle_rad: float,
    *,
    y: float | None = None,
) -> Vector:
    return Vector(
        center.X + radius * cos(angle_rad),
        center.Y if y is None else y,
        center.Z + radius * sin(angle_rad),
    )


def external_tangent_points(
    first_center: Vector,
    first_radius: float,
    second_center: Vector,
    second_radius: float,
    *,
    y: float,
) -> tuple[tuple[Vector, Vector], tuple[Vector, Vector]]:
    dx = second_center.X - first_center.X
    dz = second_center.Z - first_center.Z
    center_distance = sqrt(dx * dx + dz * dz)
    radius_delta = first_radius - second_radius
    if center_distance <= abs(radius_delta):
        raise ValueError("external tangent requires separated pitch circles")

    d_x = dx / center_distance
    d_z = dz / center_distance
    along = radius_delta / center_distance
    across = sqrt(1.0 - along * along)
    perpendicular_x = -d_z
    perpendicular_z = d_x

    normals = (
        (
            along * d_x - across * perpendicular_x,
            along * d_z - across * perpendicular_z,
        ),
        (
            along * d_x + across * perpendicular_x,
            along * d_z + across * perpendicular_z,
        ),
    )
    tangents: list[tuple[Vector, Vector]] = []
    for normal_x, normal_z in normals:
        tangents.append(
            (
                Vector(
                    first_center.X + first_radius * normal_x,
                    y,
                    first_center.Z + first_radius * normal_z,
                ),
                Vector(
                    second_center.X + second_radius * normal_x,
                    y,
                    second_center.Z + second_radius * normal_z,
                ),
            )
        )
    return tangents[0], tangents[1]


def fuse_all(shapes: list[Shape], *, label: str) -> Shape:
    if not shapes:
        raise ValueError("cannot fuse an empty shape list")
    result = shapes[0].fuse(*shapes[1:]).clean()
    solids = list(result.solids())
    if len(solids) != 1:
        bounds = [
            {
                "min": tuple(round(value, 3) for value in solid.bounding_box().min),
                "max": tuple(round(value, 3) for value in solid.bounding_box().max),
            }
            for solid in solids
        ]
        raise RuntimeError(
            f"{label} must be one connected solid, found {len(solids)}: "
            f"{bounds}"
        )
    result.label = label
    return result


def wheel_geometry(
    center: Vector,
    *,
    angle_rad: float,
    fixed_front: bool,
) -> list[Shape]:
    pieces: list[Shape] = [
        annulus_y(center, 331.0, 299.0, 32.0),
        cylinder_y(center, 34.0, 112.0),
    ]
    for index in range(10):
        angle = angle_rad + index * 2.0 * pi / 10.0
        pieces.append(
            tube(
                radial_point(center, 22.0, angle),
                radial_point(center, 315.0, angle),
                4.5,
            )
        )
    if not fixed_front:
        sprocket_center = Vector(
            center.X,
            DRIVE_PLANE_Y_MM,
            center.Z,
        )
        pieces.extend(
            [
                cylinder_y(
                    Vector(center.X, -57.5, center.Z),
                    20.0,
                    31.0,
                ),
                # The backing disc intersects only the inner 1 mm of the
                # 40/5 mm torus.  This keeps the sprocket fused to the wheel
                # while preserving an exposed toroidal STEP face whose
                # centerline is the physical 40 mm pitch loop.
                cylinder_y(sprocket_center, 36.0, 14.0),
                torus_y(
                    sprocket_center,
                    REAR_PITCH_RADIUS_MM,
                    5.0,
                ),
            ]
        )
        for index in range(6):
            angle = angle_rad + index * 2.0 * pi / 6.0
            pieces.append(
                tube(
                    radial_point(
                        sprocket_center, 15.0, angle, y=-66.0
                    ),
                    radial_point(
                        sprocket_center,
                        REAR_PITCH_RADIUS_MM,
                        angle,
                        y=DRIVE_PLANE_Y_MM,
                    ),
                    3.5,
                )
            )
        marker_angle = angle_rad + 0.31
        pieces.append(
            tube(
                radial_point(center, 305.0, marker_angle),
                radial_point(center, 350.0, marker_angle),
                9.0,
            )
        )
    return pieces


def build_rear_drive_wheel(angle_rad: float) -> Shape:
    # This is a validator-owned activation drive disc, not a replacement for
    # the submitted bicycle's visual wheel.  The exact 40/5 mm pitch torus
    # remains exposed by 0.25 mm beyond a carrier surrounding the unchanged
    # implementation-approved 36 x 14 mm backing disc.
    sprocket_center = Vector(
        REAR_CENTER.X,
        DRIVE_PLANE_Y_MM,
        REAR_CENTER.Z,
    )
    marker_center = radial_point(
        REAR_CENTER,
        110.0,
        angle_rad,
        y=0.0,
    )
    pieces = [
        cylinder_y(REAR_CENTER, 120.0, 2.0),
        cylinder_y(REAR_CENTER, 34.0, 112.0),
        cylinder_y(
            Vector(REAR_CENTER.X, -64.625, REAR_CENTER.Z),
            20.0,
            17.75,
        ),
        cylinder_y(sprocket_center, 36.0, 14.0),
        cylinder_y(sprocket_center, 44.75, 11.4),
        torus_y(
            sprocket_center,
            REAR_PITCH_RADIUS_MM,
            5.0,
        ),
        centered_box(
            marker_center,
            70.0,
            4.0,
            14.0,
            rotation_y_deg=-degrees(angle_rad),
        ),
    ]
    return fuse_all(pieces, label="activation_rear_drive_disc_and_sprocket")

def build_input_crank(angle_rad: float) -> Shape:
    # A thin backing disc nearly fills the chainring torus.  Its remaining
    # 0.25 mm exposed toroidal lip keeps the exact STEP pitch surface while
    # allowing a small independently verified convex collision inventory.
    chainring_center = Vector(
        CRANK_CENTER.X,
        DRIVE_PLANE_Y_MM,
        CRANK_CENTER.Z,
    )
    right_start = Vector(CRANK_CENTER.X, -105.0, CRANK_CENTER.Z)
    right_end = radial_point(
        CRANK_CENTER, 170.0, angle_rad, y=-105.0
    )
    right_arm_end = radial_point(
        CRANK_CENTER, 127.0, angle_rad, y=-105.0
    )
    left_start = Vector(CRANK_CENTER.X, 105.0, CRANK_CENTER.Z)
    left_end = radial_point(
        CRANK_CENTER, 170.0, angle_rad + pi, y=105.0
    )
    left_arm_end = radial_point(
        CRANK_CENTER, 127.0, angle_rad + pi, y=105.0
    )
    return fuse_all(
        [
            cylinder_y(CRANK_CENTER, 13.0, 230.0),
            cylinder_y(chainring_center, 87.75, 15.5),
            torus_y(
                chainring_center,
                INPUT_PITCH_RADIUS_MM,
                8.0,
            ),
            tube(right_start, right_arm_end, 10.0),
            tube(left_start, left_arm_end, 10.0),
            centered_box(
                right_end,
                86.0,
                32.0,
                20.0,
                rotation_y_deg=-degrees(angle_rad),
            ),
            centered_box(
                left_end,
                86.0,
                32.0,
                20.0,
                rotation_y_deg=-degrees(angle_rad),
            ),
        ],
        label="activation_input_crank_chainring_and_pedals",
    )

def build_chain_path_visualizer() -> Shape:
    # The revised authored chain solid lies in the governed sprocket pitch
    # plane.  Its closed centerline, wrap, and thickness are measured by the
    # Harness and bind the runtime moving-chain path to the finite compliant
    # transmission model; it is not decorative offset geometry.
    chainring_center = Vector(
        CRANK_CENTER.X,
        DRIVE_PLANE_Y_MM,
        CRANK_CENTER.Z,
    )
    rear_sprocket_center = Vector(
        REAR_CENTER.X,
        DRIVE_PLANE_Y_MM,
        REAR_CENTER.Z,
    )
    dx = rear_sprocket_center.X - chainring_center.X
    dz = rear_sprocket_center.Z - chainring_center.Z
    center_distance = sqrt(dx * dx + dz * dz)
    basis_u_x = dx / center_distance
    basis_u_z = dz / center_distance
    basis_v_x = basis_u_z
    basis_v_z = -basis_u_x
    radial_u = (
        INPUT_PITCH_RADIUS_MM - REAR_PITCH_RADIUS_MM
    ) / center_distance
    radial_v = sqrt(1.0 - radial_u * radial_u)
    tangent_angle = atan2(radial_v, radial_u)

    def path_point(
        center: Vector,
        radius: float,
        angle: float,
    ) -> Vector:
        return Vector(
            center.X
            + radius
            * (basis_u_x * cos(angle) + basis_v_x * sin(angle)),
            DRIVE_PLANE_Y_MM,
            center.Z
            + radius
            * (basis_u_z * cos(angle) + basis_v_z * sin(angle)),
        )

    input_plus = path_point(
        chainring_center,
        INPUT_PITCH_RADIUS_MM,
        tangent_angle,
    )
    output_plus = path_point(
        rear_sprocket_center,
        REAR_PITCH_RADIUS_MM,
        tangent_angle,
    )
    output_sweep = -2.0 * tangent_angle
    output_arc = [
        path_point(
            rear_sprocket_center,
            REAR_PITCH_RADIUS_MM,
            tangent_angle + output_sweep * index / 48.0,
        )
        for index in range(49)
    ]
    input_minus = path_point(
        chainring_center,
        INPUT_PITCH_RADIUS_MM,
        -tangent_angle,
    )
    input_sweep = -(2.0 * pi - 2.0 * tangent_angle)
    input_arc = [
        path_point(
            chainring_center,
            INPUT_PITCH_RADIUS_MM,
            -tangent_angle + input_sweep * index / 48.0,
        )
        for index in range(49)
    ]
    centerline = [
        input_plus,
        output_plus,
        *output_arc[1:],
        input_minus,
        *input_arc[1:],
    ]
    segments = [
        extended_tube(left, right, 3.0, 0.75)
        for left, right in zip(centerline, centerline[1:])
    ]
    return fuse_all(segments, label="visible_closed_chain_path")

def build_laboratory_chassis() -> Shape:
    pieces: list[Shape] = [
        centered_box(Vector(0.0, 0.0, 23.0), 2150.0, 330.0, 46.0)
    ]

    # Fixed front wheel and fork make the assembly recognizable while the
    # rear wheel remains the sole task target.
    pieces.extend(
        wheel_geometry(FRONT_CENTER, angle_rad=0.0, fixed_front=True)
    )
    head = Vector(610.0, 60.0, 730.0)
    pieces.extend(
        [
            tube(Vector(610.0, 60.0, 700.0), Vector(610.0, 60.0, 900.0), 18.0),
            tube(Vector(610.0, 60.0, 875.0), Vector(610.0, -150.0, 875.0), 14.0),
            tube(Vector(610.0, -150.0, 875.0), Vector(610.0, -190.0, 875.0), 22.0),
            tube(Vector(610.0, 60.0, 875.0), Vector(610.0, 210.0, 875.0), 14.0),
            tube(Vector(610.0, 210.0, 875.0), Vector(610.0, 245.0, 875.0), 22.0),
            tube(head, Vector(FRONT_CENTER.X, 48.0, FRONT_CENTER.Z), 18.0),
            tube(head, Vector(FRONT_CENTER.X, -48.0, FRONT_CENTER.Z), 18.0),
        ]
    )

    # Finite annular bearing geometry around the moving crank and
    # rear axle leaves bounded radial clearance without collision exemptions.
    # Both shafts retain visible finite annular bearing geometry.
    for y in (-40.0, 123.6):
        crank_bearing = Vector(CRANK_CENTER.X, y, CRANK_CENTER.Z)
        pieces.extend(
            [
                annulus_y(crank_bearing, 40.0, 13.6, 16.0),
                tube(
                    Vector(CRANK_CENTER.X, y, 45.0),
                    Vector(CRANK_CENTER.X, y, CRANK_CENTER.Z - 32.0),
                    22.0,
                ),
            ]
        )

    for y in (-40.0, 62.0):
        rear_bearing = Vector(REAR_CENTER.X, y, REAR_CENTER.Z)
        pieces.extend(
            [
                annulus_y(rear_bearing, 54.0, 34.6, 16.0),
                tube(
                    Vector(REAR_CENTER.X, y, 45.0),
                    Vector(REAR_CENTER.X, y, REAR_CENTER.Z - 42.0),
                    22.0,
                ),
            ]
        )

    # Bicycle frame triangle on the drive-side plane.
    y = 64.0
    seat_cluster = Vector(-245.0, y, 785.0)
    pieces.extend(
        [
            tube(
                Vector(CRANK_CENTER.X, y, CRANK_CENTER.Z + 32.0),
                seat_cluster,
                24.0,
            ),
            tube(seat_cluster, head, 24.0),
            tube(
                head,
                Vector(CRANK_CENTER.X + 32.0, y, CRANK_CENTER.Z),
                25.0,
            ),
            tube(
                Vector(CRANK_CENTER.X - 32.0, y, CRANK_CENTER.Z),
                Vector(REAR_CENTER.X + 50.0, y, REAR_CENTER.Z),
                20.0,
            ),
            tube(
                seat_cluster,
                Vector(REAR_CENTER.X, y, REAR_CENTER.Z + 50.0),
                19.0,
            ),
            tube(seat_cluster, Vector(-245.0, y, 830.0), 16.0),
            tube(
                Vector(CRANK_CENTER.X, y, CRANK_CENTER.Z - 32.0),
                Vector(CRANK_CENTER.X, y, 45.0),
                24.0,
            ),
            centered_box(Vector(-275.0, y, 830.0), 190.0, 105.0, 28.0),
        ]
    )

    # A second down-stay braces the head to the laboratory base.
    pieces.append(
        tube(Vector(700.0, 64.0, 45.0), head, 22.0)
    )
    return fuse_all(pieces, label="fixed_laboratory_bicycle_chassis")


def build_assembly(
    *,
    crank_angle_rad: float,
    rear_angle_rad: float,
) -> Compound:
    chassis = build_laboratory_chassis()
    crank = build_input_crank(crank_angle_rad)
    rear = build_rear_drive_wheel(rear_angle_rad)
    chain_path = build_chain_path_visualizer()
    return Compound(
        children=[chassis, crank, rear, chain_path],
        label="cleanroom_bicycle_drivetrain_demonstrator",
    )


def write_step(assembly: Compound, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not export_step(
        assembly,
        destination,
        timestamp=DETERMINISTIC_TIMESTAMP,
    ):
        raise RuntimeError(f"STEP export failed: {destination}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--package-dir",
        type=Path,
        default=Path(__file__).resolve().parent,
    )
    parser.add_argument(
        "--review-dir",
        type=Path,
        default=Path(__file__).resolve().parent.parent / "visual_review",
    )
    args = parser.parse_args()
    package_dir = args.package_dir.resolve()
    review_dir = args.review_dir.resolve()

    write_step(
        build_assembly(crank_angle_rad=0.0, rear_angle_rad=0.0),
        package_dir / "assembly.step",
    )
    write_step(
        build_assembly(crank_angle_rad=1.50, rear_angle_rad=3.00),
        review_dir / "pose_steps" / "powered_pose.step",
    )
    write_step(
        build_assembly(crank_angle_rad=0.05, rear_angle_rad=0.10),
        review_dir / "pose_steps" / "returned_pose.step",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
